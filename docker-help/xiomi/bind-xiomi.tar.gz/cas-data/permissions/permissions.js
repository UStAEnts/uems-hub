const data = module.exports = {
    permissions: {
        'casvii.permission.grant.other': 'Allows the user to grant permissions to other users',
        'casvii.permission.grant.self': 'Allows the user to grant permissions to themselves',
        'casvii.permission.ungrant.other': 'Allows the user to revoke permissions from other users',
        'casvii.permission.ungrant.self': 'Allows the user to revoke permissions from themselves',
        'casvii.permission.self-grant': 'Allows the user to use self grant authorization requests (disables logging into new microsites if not granted)',
        'casvii.self-serve.password': 'Allows the user to change their own password',
        'casvii.has-email': 'Allows the user to see the staff email configuration page'
    },
    groups: {
        'default': {
            description: 'The default user permission group allowing basic permissions across the system',
            permissions: [
                'casvii.permission.self-grant',
                'casvii.self-serve.password',
            ],
            inherits: [],
        },
        'staff': {
            description: 'For all staff members, allows access to basic utilities like the email configuration system',
            permissions: [
                'casvii.has-email',
            ],
            inherits: [
                'default',
            ],
        },
        'admin': {
            description: 'Permissions held by the admin users, allows all functions on the site',
            permissions: [
                'casvii.permission.grant.other',
                'casvii.permission.grant.self',
                'casvii.permission.ungrant.other',
                'casvii.permission.ungrant.self',
            ],
            inherits: [
                'default',
                'staff',
            ],
        }
    }
};
