'use strict';

module.exports = {
    /**
     * @param {QueryInterface} queryInterface
     */
    up: function (queryInterface) {
        // Describe how to achieve the task.
        // Call resolve/reject at some point.
        return queryInterface.sequelize.query(`ALTER TABLE "Users" ADD COLUMN registered BOOLEAN;`);
    },

    /**
     * @param {QueryInterface} queryInterface
     */
    down: function (queryInterface) {
        return queryInterface.sequelize.query(`ALTER TABLE "Users" DROP COLUMN registered;`);
    }
};
