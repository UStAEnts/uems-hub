'use strict';

module.exports = {
    /**
     * @param {QueryInterface} queryInterface
     */
    up: function (queryInterface) {
        // Describe how to achieve the task.
        // Call resolve/reject at some point.
        return queryInterface.sequelize.transaction(async t => {
            await queryInterface.sequelize.query(`alter table "RegistrationTokens"
                add column if not exists "createdAt" timestamp with time zone default now();`, {transaction: t});
            await queryInterface.sequelize.query(`alter table "RegistrationTokens"
                add column if not exists "updatedAt" timestamp with time zone default now();`, {transaction: t});
        })
    },

    /**
     * @param {QueryInterface} queryInterface
     */
    down: function (queryInterface) {
        return queryInterface.sequelize.transaction(async t => {
            await queryInterface.sequelize.query(`alter table "RegistrationTokens"
                drop column if exists "createdAt";`, {transaction: t});
            await queryInterface.sequelize.query(`alter table "RegistrationTokens"
                drop column if exists "updatedAt";`, {transaction: t});
        });
    }
};
