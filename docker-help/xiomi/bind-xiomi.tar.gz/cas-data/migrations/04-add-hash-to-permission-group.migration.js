'use strict';

module.exports = {
    /**
     * @param {QueryInterface} queryInterface
     */
    up: function (queryInterface) {
        // Describe how to achieve the task.
        // Call resolve/reject at some point.
        return queryInterface.sequelize.query(`alter table "PermissionGroups" add hash text default '[nohash]';`);
    },

    /**
     * @param {QueryInterface} queryInterface
     */
    down: function (queryInterface) {
        return queryInterface.sequelize.query(`alter table "PermissionGroups" drop column hash;`);
    }
};
