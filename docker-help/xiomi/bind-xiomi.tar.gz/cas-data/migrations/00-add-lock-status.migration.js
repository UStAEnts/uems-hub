'use strict';

module.exports = {
    /**
     * @param {QueryInterface} queryInterface
     */
    up: function (queryInterface) {
        // Describe how to achieve the task.
        // Call resolve/reject at some point.
        return queryInterface.sequelize.query(`ALTER TYPE "enum_Users_lockedStatus" ADD VALUE 'two_factor_setup';`);
    },

    down: function () {
        return Promise.reject('Cannot tear down an enum change (see https://stackoverflow.com/a/39878233 and https://www.postgresql.org/docs/9.1/sql-altertype.html)');
    }
};