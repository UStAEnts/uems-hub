'use strict';

module.exports = {
    /**
     * @param {QueryInterface} queryInterface
     */
    up: function (queryInterface) {
        // Describe how to achieve the task.
        // Call resolve/reject at some point.
        return queryInterface.sequelize.query(`alter table "TwoFactorConfigurations" add "emailOnFail" boolean default true;`);
    },

    /**
     * @param {QueryInterface} queryInterface
     */
    down: function (queryInterface) {
        return queryInterface.sequelize.query(`alter table "TwoFactorConfigurations" drop column "emailOnFail";`);
    }
};
