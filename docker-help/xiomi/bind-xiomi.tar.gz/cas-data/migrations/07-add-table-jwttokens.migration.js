'use strict';

module.exports = {
    /**
     * @param {QueryInterface} queryInterface
     */
    up: function (queryInterface) {
        // Describe how to achieve the task.
        // Call resolve/reject at some point.
        return queryInterface.sequelize.transaction(async (t) => {
            await queryInterface.sequelize.query(`create table "JWTTokens"
                                                  (
                                                      id                    serial                                                  not null,
                                                      "tokenID"             text                                                    not null,
                                                      revoked               boolean                     default false               not null,
                                                      assigned              timestamp with time zone    default CURRENT_TIMESTAMP   not null,
                                                      "clientIdentifier"    text                                                    not null,
                                                      "userID"              int                                                     not null,
                                                      "createdAt"           timestamp with time zone    default now()               not null,
                                                      "updatedAt"           timestamp with time zone    default now()               not null
                                                  );`, {transaction: t});
            await queryInterface.sequelize.query(`create unique index "JWTTokens_id_uindex" on "JWTTokens" (id);`, {transaction: t});
            await queryInterface.sequelize.query(`alter table "JWTTokens" add constraint "JWTTokens_pk" primary key (id);`, {transaction: t});
        });
    },

    /**
     * @param {QueryInterface} queryInterface
     */
    down: function (queryInterface) {
        return queryInterface.sequelize.query(`DROP TABLE IF EXISTS "JWTTokens";`);
    }
};
