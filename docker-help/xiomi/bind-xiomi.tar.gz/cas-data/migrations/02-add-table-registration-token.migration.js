'use strict';

module.exports = {
    /**
     * @param {QueryInterface} queryInterface
     */
    up: function (queryInterface) {
        // Describe how to achieve the task.
        // Call resolve/reject at some point.
        return queryInterface.sequelize.transaction(async (t) => {
            await queryInterface.sequelize.query(`create table "RegistrationTokens"
                                                  (
                                                      id         serial                            not null,
                                                      requested  timestamp with time zone     default CURRENT_TIMESTAMP not null,
                                                      "userID"     int                               not null
                                                          constraint RegistrationTokens_Users__fk
                                                              references "Users",
                                                      "userToken"  text                              not null,
                                                      "resetToken" text                              not null,
                                                      completed  boolean default false             not null
                                                  );`, {transaction: t});
            await queryInterface.sequelize.query(`create unique index "RegistrationTokens_id_uindex" on "RegistrationTokens" (id);`, {transaction: t});
            await queryInterface.sequelize.query(`alter table "RegistrationTokens" add constraint "RegistrationTokens_pk" primary key (id);`, {transaction: t});
        });
    },

    /**
     * @param {QueryInterface} queryInterface
     */
    down: function (queryInterface) {
        return queryInterface.sequelize.query(`DROP TABLE IF EXISTS RegistrationTokens;`);
    }
};
