module.exports = {
  "dev": {
    "http": 3000,
    "https": 3001
  },
  "prod": {
    "http": 80,
    "https": 443
  }
};
