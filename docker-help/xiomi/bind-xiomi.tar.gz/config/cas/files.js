module.exports = {
    "file-servers": [
        {
            "domain": "xiomi.org",
            "path": "p/global",
            "authentication": "ANY",
            "subdomain": "*",
            "fileRoot": "/files/global/public"
        },
        // Serving public CAS files at /p/cas/...
        // Allows any authentication
        {
            "domain": "xiomi.org",
            "path": "p/cas",
            "authentication": "ANY",
            "subdomain": "cas",
            "fileRoot": "/files/subdomains/cas/public",
        },
        // Serving private CAS files at /s/cas/...
        // Requires authentication
        {
            "domain": "xiomi.org",
            "path": "s/cas",
            "authentication": "AUTHENTICATED",
            "subdomain": "cas",
            "fileRoot": "/files/subdomains/cas/secure",
        },
        {
            "domain": "xiomi.org",
            "path": "",
            "authentication": "ANY",
            "subdomain": "*",
            "fileRoot": "/files/root",
        }
    ]
};
