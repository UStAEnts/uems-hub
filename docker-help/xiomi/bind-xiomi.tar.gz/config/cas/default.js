module.exports = {
    "cas": {
        "connection": {
            "host": "uems_db",
            "database": "xiomi_cas",
            "dialect": "postgres",
            "username": "cas",
            "password": "web_backend"
        },
        "email": {
            "from": "CAS Core <cas@xiomi.org>",
            "configuration": {
                "host": 'undefined.productions',
                "port": 25,
                "secure": false,
                "auth": {
                    "user": '',
                    "pass": '',
                }
            }
        },
        "authorized-applications": {
            "uems": {
                "identifier": "uemsv0.0.1",
                "endpoint": "https://uems.ryan.ax370:3001/authorize/receive",
            }
        },
        "jwt": {
            "private": "certs/jwt/jwtRS256.key"
        },
        "message-broker": {
            "enabled": true,
            "username": "xssso",
            "password": "Lrn6t8@P5uH3ONW%9WVf",
            "host": "rabbit-uems",
            "port": "5672",
            "vhost": "/"
        },
        "bypass-email": true
    }
};
