const uuid = require('uuid');
module.exports = {
  "environment": "dev",
  "server": {
    "ssl": {
      "private": "certs/xiomi.key",
      "certificate": "certs/xiomi.crt"
    }
  },
  "session": {
    "secret": "xiomi-internal-secret",
    "resave": true,
    "saveUninitialized": false,
    "cookie": {
      "path": "/",
      "domain": "{$_domain}",
      "httpOnly": true,
      "secure": true,
    },
      "genid": () => uuid.v4().toString(),
      "proxy": false,
  },
  "database": {
    "user": "",
    "host": "",
    "password": "",
    "port": 0,
    "preconnect": [
    ],
    "type": "sqljs"
  },
  "log-directory": "logs",
  "load": ["components.js"],
  "include-cas": true,
  "silent-duplicate-headers": true,
  "jwt": {
    "public": "certs/jwt.public",
    "private": "certs/jwt.private",
    "cookie": "sto"
  }
};
