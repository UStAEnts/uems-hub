module.exports = {
	"components": [
		'../../endpoint/build/index.js',
	]
}