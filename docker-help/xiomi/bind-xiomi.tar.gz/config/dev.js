module.exports = {
    "server": {
        "ssl": {
            "private": "certs/localhost.key",
            "certificate": "certs/localhost.crt"
        }
    },
};
