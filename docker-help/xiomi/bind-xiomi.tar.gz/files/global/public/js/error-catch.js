(function () {
    let originals = {
        _error: console.error,
        _warn: console.warn,
        _exception: console.exception
    };

    function buildTarget() {
        // Cut down the stack trace removing any lines that start with at. This will just leave the trace list
        let lines = new Error().stack.split("\n").map(e => e.trim()).map(e => e.startsWith("at ") ? e.substr(3) : e);
        if (lines.length >= 3) {
            // Remove the first line
            lines.shift();
            // Select the second line which will be 2 calls away
            return lines[2];
        }

        return "unknown origin";
    }

    function deploy(target, outputs, level) {
        // We don't actually care for the output here. If it hits the server then great, if not then not much we
        // can do about it
        $.ajax({
            url: "/api/error-catcher",
            method: "POST",
            data: JSON.stringify({
                source: target,
                at: new Date(),
                level: level,
                messages: outputs
            }),
            contentType: "application/json; charset=UTF-8"
        });
    }

    console.error = function () {
        let outputs = [];
        for (let object of arguments) {
            if (object === undefined) object = 'undefined';
            if (object === null) object = 'null';

            try {
                outputs.push(object.toString());
            } catch (e) {
                outputs.push('object that threw an error during #toString of type ' + typeof (object));
            }
        }
        let target = buildTarget();
        deploy(target, outputs, 'ERROR');

        originals._error.apply(this, Array.prototype.slice.call(arguments));
    };

    console.exception = function () {
        let outputs = [];
        for (let object of arguments) {
            if (object === undefined) object = 'undefined';
            if (object === null) object = 'null';
            try {
                outputs.push(object.valueOf());
            } catch (e) {
                outputs.push('object that threw an error during #valueOf of type ' + typeof (object));
            }
        }
        let target = buildTarget();
        deploy(target, outputs, 'EXCEPTION');

        originals._exception.apply(this, Array.prototype.slice.call(arguments));
    };

    console.warn = function () {
        let outputs = [];
        for (let object of arguments) {
            if (object === undefined) object = 'undefined';
            if (object === null) object = 'null';
            try {
                outputs.push(object.valueOf());
            } catch (e) {
                outputs.push('object that threw an error during #valueOf of type ' + typeof (object));
            }
        }
        let target = buildTarget();
        deploy(target, outputs, 'WARN');

        originals._warn.apply(this, Array.prototype.slice.call(arguments));
    }
})();
