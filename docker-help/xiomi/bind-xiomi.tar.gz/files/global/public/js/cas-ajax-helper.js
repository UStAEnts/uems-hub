(function () {

    /**
     * Validates the response to make sure it contains only valid fields being returned from the server
     * @param response {jqXHR}
     */
    function validateResponse(response) {
        if (!response.hasOwnProperty('responseJSON')) {
            console.debug('Response from server did not contain a "responseJSON" entry');
            return false;
        }

        const json = response.responseJSON;

        if (!json.hasOwnProperty('success')) {
            console.debug('Response from server did not contain a "success" entry');
            return false;
        }
        if (typeof (json.success) !== "string" && typeof (json.success) !== "boolean") {
            console.debug('Response from server contained "success" but it was not a "string" or a "boolean"');
            return false;
        }
        if (!json.hasOwnProperty('message') && !json.hasOwnProperty('error')) {
            console.debug('Response from server did not contain a "message" or an "error"');
            return false;
        }
        if (json.hasOwnProperty('message') && typeof (json.message) !== "string") {
            console.debug('Response from server contained "message" but it was not a "string"');
            return false;
        }
        if (json.hasOwnProperty('error') && typeof (json.error) !== "string") {
            console.debug('Response from server contained "error" but it was not a "string"');
            return false;
        }
        if (json.hasOwnProperty('url') && typeof (json.url) !== "string") {
            console.debug('Response from server contained "url" but it was not a "string"');
            return false;
        }

        // Only specific keys are allowed
        let validKeys = ['success', 'message', 'support', 'url', 'error'];
        for (let key of Object.keys(json)) {
            if (validKeys.indexOf(key) === -1) {
                console.debug('Response from server contained invalid key "' + key + '"');
                return false;
            }
        }

        if (json.success === true && json.hasOwnProperty('error')) {
            console.debug('Response from server contained a positive result but contained an "error" key');
            return false;
        }
        if (json.success === false && !json.hasOwnProperty('error')) {
            console.debug('Response from server contained a negative result but did not contain an "error" key');
            return false;
        }
        if (json.success === false && !json.hasOwnProperty('support')) {
            console.debug('Response from server contained a negative result but did not contain a "support" key');
            return false;
        }

        return true;
    }

    /**
     * Shows the given message with the color in the '#error' component. If small is not undefined, it will be appended
     * to the '#error' element as a '<small>'.
     * @param message {string} the message to be displayed to the user
     * @param color {string} the color of the error string
     * @param small {string|undefined} the small text to show in the request, if valid
     */
    function showRaw(message, color, small) {
        let error = $('#error');

        error
            .empty()
            .text(message)
            .append($('<br>'));

        if (small !== undefined) {
            let support = $('<small>').text(small);
            error.append(support);
        }

        error
            .css('color', color)
            .css('visibility', 'visible');
    }

    /**
     * Sets text on the '#error' element, sets its CSS color to red and makes it visible
     * @param message {string} the message to display in the error window
     * @param support {string|undefined} the support UUID
     */
    function showError(message, support) {
        let output = support === undefined ? undefined : 'If you wish to contact support, please quote ' + support + ' to them to help find your query.';

        showRaw('Error: ' + message, 'red', output);
    }

    /**
     * Shows the given message in green in the '#error' component.
     * @param message {string} the message to display
     */
    function showSuccess(message) {
        showRaw(message, 'green', undefined);
    }

    /**
     * Sets the visibility CSS property of the #error element hidden
     */
    function hideError() {
        $('#error').css('visibility', 'hidden');
    }

    /**
     * Performs an AJAX POST request to the endpoint using the given CSRF header with the stringified data
     * @param url {string} the url of the API endpoint
     * @param data {any} the data object to be converted to JSON
     * @param csrf {string} the CSRF token to validate this request
     * @param customSuccess {Function|undefined} a custom success handler, see {@link handleAJAXResponse} for more information
     * @param unexpectedFailure {Function|undefined} a custom unexpected failure handler, see {@link handleAJAXResponse} for more information
     * @returns {*} the raw result of $.ajax
     */
    window.performAPIPost = function (
        url,
        data,
        csrf,
        customSuccess,
        unexpectedFailure,
    ) {
        hideError();
        return $.ajax({
            method: "POST",
            url: url,
            contentType: "application/json; charset=utf-8",
            data: JSON.stringify(data),
            headers: {
                'CSRF-Token': csrf,
            }
        }).done(function (data, textStatus, jqXHR) {
            handleAJAXResponse(customSuccess, jqXHR, unexpectedFailure, false);
        }).fail(function (jqXHR) {
            handleAJAXResponse(customSuccess, jqXHR, unexpectedFailure, true);
        });
    };

    /**
     *
     * @param customSuccess {Function|undefined}
     * @param response {jqXHR}
     * @param unexpectedResult {Function|undefined}
     * @param failure {boolean|undefined}
     */
    window.handleAJAXResponse = function (
        customSuccess, /*function*/
        response, /*any*/
        unexpectedResult, /*function*/
        failure, /*boolean*/
    ) {
        if (failure === undefined) failure = false;

        if (!validateResponse(response)) {
            showError('Received an unexpected response from the server! Please inform support by emailing admin@xiomi.org', undefined);
            return;
        }

        // At this point the type changes
        // noinspection JSValidateTypes,UnnecessaryLocalVariableJS
        /**
         * @type {{success: string|boolean,message:string,error:string,url?:string,support?:string}}
         */
        let clean = response.responseJSON;

        // If we return a URL, we must redirect
        if (!failure && clean.hasOwnProperty('url') && clean.url !== undefined) {
            window.location.href = clean.url;
            return;
        }

        // If it is successful, show the message and call the custom successful function
        if (clean.success === true) {
            showSuccess(clean.message);
            if (customSuccess !== undefined) customSuccess(clean);
            return;
        }

        // If it is not, then show an error
        if (clean.success === false) {
            showError(clean.error, clean.support);
        }

        // Otherwise, we need to pass off the request
        if (unexpectedResult !== undefined) unexpectedResult(clean);
    };
})();
